import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../../api/axiosInstance";
import { formatCurrency } from "../../utils/formatters";
import {
  Shield, Users, ParkingSquare, Car, Truck, Tag,
  DollarSign, BarChart2, TrendingUp, CheckCircle,
  Clock, Star, Layers
} from "lucide-react";

const SuperAdminDashboard = () => {
  const navigate          = useNavigate();
  const [stats, setStats] = useState(null);
  const [loading, setL]   = useState(true);

  useEffect(() => {
    axiosInstance.get("/api/super-admin/platform-stats")
      .then((r) => setStats(r.data))
      .catch(() => setStats(null))
      .finally(() => setL(false));
  }, []);

  const navCards = [
    { icon: ParkingSquare, label: "Lot Admins",   to: "/super-admin/lot-admins",   color: "bg-blue-50 text-blue-600" },
    { icon: Car,           label: "Car Owners",   to: "/super-admin/car-owners",   color: "bg-green-50 text-green-600" },
    { icon: Truck,         label: "Fleet Admins", to: "/super-admin/fleet-admins", color: "bg-amber-50 text-amber-600" },
    { icon: Tag,           label: "Promo Codes",  to: "/super-admin/promos",       color: "bg-purple-50 text-purple-600" },
    { icon: Users,         label: "All Users",    to: "/super-admin/users",        color: "bg-red-50 text-red-600" },
  ];

  const StatCard = ({ label, value, icon: Icon, color, bg }) => (
    <div className="stat-card">
      <div className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center flex-shrink-0`}>
        <Icon size={18} className={color} />
      </div>
      <div>
        <div className={`font-display text-xl font-bold ${color}`}>{value}</div>
        <div className="text-xs text-gray-500 mt-0.5">{label}</div>
      </div>
    </div>
  );

  return (
    <div className="page-container space-y-8">

      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-red-50 rounded-xl flex items-center justify-center">
          <Shield size={20} className="text-red-500" />
        </div>
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900">Platform Dashboard</h1>
          <p className="text-gray-500 text-sm">Full platform overview and management</p>
        </div>
      </div>

      {/* Stats */}
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {[1,2,3,4].map((i) => (
            <div key={i} className="bg-white rounded-2xl border border-gray-100 h-24 animate-pulse" />
          ))}
        </div>
      ) : stats ? (
        <div className="space-y-6">

          {/* Row 1 — Platform totals */}
          <div>
            <h2 className="section-title mb-3">Platform Overview</h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <StatCard label="Total Users"       value={stats.totalUsers        ?? 0}                          icon={Users}        color="text-blue-600"   bg="bg-blue-50"   />
              <StatCard label="Parking Lots"      value={stats.totalParkingLots  ?? 0}                          icon={ParkingSquare} color="text-green-600"  bg="bg-green-50"  />
              <StatCard label="Total Slots"       value={stats.totalSlots        ?? 0}                          icon={Layers}       color="text-amber-600"  bg="bg-amber-50"  />
              <StatCard label="Available Slots"   value={stats.availableSlots    ?? 0}                          icon={CheckCircle}  color="text-teal-600"   bg="bg-teal-50"   />
            </div>
          </div>

          {/* Row 2 — Revenue */}
          <div>
            <h2 className="section-title mb-3">Revenue</h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <StatCard label="Today"       value={formatCurrency(stats.totalRevenueToday     ?? 0)} icon={DollarSign}  color="text-emerald-600" bg="bg-emerald-50" />
              <StatCard label="This Week"   value={formatCurrency(stats.totalRevenueThisWeek  ?? 0)} icon={TrendingUp}  color="text-blue-600"    bg="bg-blue-50"   />
              <StatCard label="This Month"  value={formatCurrency(stats.totalRevenueThisMonth ?? 0)} icon={BarChart2}   color="text-purple-600"  bg="bg-purple-50" />
              <StatCard label="All Time"    value={formatCurrency(stats.totalRevenueAllTime   ?? 0)} icon={Star}        color="text-sp-blue"     bg="bg-blue-50"   />
            </div>
          </div>

          {/* Row 3 — Bookings & Valets */}
          <div>
            <h2 className="section-title mb-3">Bookings & Valets</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              <StatCard label="Bookings Today"     value={stats.totalBookingsToday     ?? 0} icon={BarChart2}  color="text-amber-600"  bg="bg-amber-50"  />
              <StatCard label="Active Bookings"    value={stats.totalActiveBookings    ?? 0} icon={Clock}      color="text-teal-600"   bg="bg-teal-50"   />
              <StatCard label="Completed Bookings" value={stats.totalCompletedBookings ?? 0} icon={CheckCircle} color="text-green-600" bg="bg-green-50"  />
              <StatCard label="Valet Requests Today" value={stats.totalValetRequestsToday ?? 0} icon={Car}     color="text-purple-600" bg="bg-purple-50" />
              <StatCard label="Active Valets"      value={stats.activeValets           ?? 0} icon={Users}      color="text-blue-600"   bg="bg-blue-50"   />
              <StatCard label="Occupied Slots"     value={stats.occupiedSlots          ?? 0} icon={Layers}     color="text-red-600"    bg="bg-red-50"    />
            </div>
          </div>

          {/* Top Parking Lots */}
          {stats.topParkingLots?.length > 0 && (
            <div>
              <h2 className="section-title mb-3">Top Parking Lots</h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {stats.topParkingLots.map((lot, i) => (
                  <div key={lot.lotId} className="bg-white border border-gray-100 rounded-2xl p-4 space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-gray-400">#{i + 1}</span>
                      <span className="font-semibold text-gray-900 text-sm truncate">{lot.lotName}</span>
                    </div>
                    <div className="text-green-600 font-bold text-base">{formatCurrency(lot.revenue)}</div>
                    <div className="text-xs text-gray-500">{lot.bookings} bookings</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Top Valets */}
          {stats.topValets?.length > 0 && (
            <div>
              <h2 className="section-title mb-3">Top Valets</h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {stats.topValets.map((valet, i) => (
                  <div key={valet.valetId} className="bg-white border border-gray-100 rounded-2xl p-4 space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-gray-400">#{i + 1}</span>
                      <span className="font-semibold text-gray-900 text-sm truncate">{valet.valetName}</span>
                    </div>
                    <div className="text-emerald-600 font-bold text-base">{formatCurrency(valet.totalEarned)}</div>
                    <div className="text-xs text-gray-500">{valet.jobsCompleted} jobs completed</div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      ) : (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl px-4 py-3 text-xs text-amber-800">
          Platform stats unavailable. Check backend connectivity.
        </div>
      )}

      {/* Navigation */}
      <div>
        <h2 className="section-title mb-4">Management</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {navCards.map(({ icon: Icon, label, to, color }) => (
            <button key={label} onClick={() => navigate(to)}
              className="bg-white border border-gray-100 rounded-2xl p-5 text-left hover:shadow-md transition-all">
              <div className={`w-10 h-10 rounded-xl ${color} flex items-center justify-center mb-3`}>
                <Icon size={18} />
              </div>
              <div className="font-semibold text-gray-900 text-sm">{label}</div>
            </button>
          ))}
        </div>
      </div>

    </div>
  );
};

export default SuperAdminDashboard;