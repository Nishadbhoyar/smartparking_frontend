import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import axiosInstance from "../../api/axiosInstance";
import toast from "react-hot-toast";
import {
  ParkingSquare, CalendarCheck, BarChart2, MessageSquare,
  TrendingUp, Clock, ArrowRight, ScanLine, LogIn
} from "lucide-react";
import { formatCurrency } from "../../utils/formatters";

const LotAdminDashboard = () => {
  const { user }        = useAuth();
  const navigate        = useNavigate();
  const [lots, setLots] = useState([]);
  const [bookings, setB]  = useState([]);
  const [loading, setL]   = useState(true);
  const [error, setError] = useState(false);

  // Quick verify from dashboard
  const [quickCode, setQuickCode]   = useState("");
  const [verifying, setVerifying]   = useState(false);
  const [defaultLotId, setDefault]  = useState(null);

  useEffect(() => {
    if (!user?.id) return;
    setError(false);
    Promise.all([
      axiosInstance.get(`/api/parking-lots/admin/${user.id}`).then((r) => r.data || []),
      axiosInstance.get(`/api/bookings/lot-admin/${user.id}`).then((r) => r.data || []),
    ])
      .then(([l, b]) => {
        setLots(l);
        setB(b);
        if (l.length) setDefault(l[0].id);
      })
      .catch(() => {
        setError(true);
        toast.error("Failed to load dashboard data. Please refresh.");
      })
      .finally(() => setL(false));
  }, [user]);

  const activeLots     = lots.filter((l) => l.status === "ACTIVE").length;
  const activeBookings = bookings.filter((b) => b.status === "ACTIVE").length;
  const pendingBookings = bookings.filter((b) => b.status === "PENDING").length;
  const revenue        = bookings
    .filter((b) => b.status === "COMPLETED")
    .reduce((s, b) => s + (b.totalAmount || 0), 0);

  // Quick verify from the dashboard input
  const handleQuickVerify = async () => {
    if (!quickCode.trim() || !defaultLotId) return;
    setVerifying(true);
    try {
      await axiosInstance.post("/api/bookings/verify-code", null, {
        params: { code: quickCode.trim().toUpperCase(), lotId: defaultLotId },
      });
      toast.success(`${quickCode.trim().toUpperCase()} — customer checked in!`);
      setQuickCode("");
      // Refresh bookings count
      axiosInstance.get(`/api/bookings/lot-admin/${user.id}`)
        .then((r) => setB(r.data || []));
    } catch (err) {
      toast.error(err?.response?.data?.message || "Invalid booking code or wrong lot.");
    } finally {
      setVerifying(false);
    }
  };

  const quickActions = [
    { icon: ScanLine,      label: "Verify Arrival", sub: "Check in customers",    to: "/lot-admin/bookings", color: "bg-green-50 text-green-600" },
    { icon: ParkingSquare, label: "My Lots",         sub: "View & manage lots",   to: "/lot-admin/lots",     color: "bg-blue-50 text-blue-600" },
    { icon: CalendarCheck, label: "Bookings",        sub: "All slot bookings",    to: "/lot-admin/bookings", color: "bg-amber-50 text-amber-600" },
    // FIX: was /lot-admin/lots — AnalyticsPage needs a lotId param
    { icon: BarChart2,     label: "Analytics",       sub: "Revenue & occupancy",  to: lots.length > 0 ? `/lot-admin/analytics/${lots[0].id}` : "/lot-admin/lots", color: "bg-purple-50 text-purple-600" },
    { icon: MessageSquare, label: "Feedback",        sub: "Customer reviews",     to: "/lot-admin/feedback", color: "bg-red-50 text-red-600" },
  ];

  return (
    <div className="page-container space-y-8">

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl px-4 py-3 flex items-center justify-between">
          <span>Could not load dashboard data.</span>
          <button onClick={() => window.location.reload()} className="text-xs font-semibold underline ml-4">Retry</button>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900">Lot Admin Dashboard</h1>
          <p className="text-gray-500 text-sm mt-1">Manage your parking lots and track performance.</p>
        </div>
        <button onClick={() => navigate("/lot-admin/lots")} className="btn-primary flex items-center gap-2 text-sm">
          <ParkingSquare size={15} /> My Lots <ArrowRight size={14} />
        </button>
      </div>

      {/* ── Quick Verify Panel ──────────────────────────────────────────────── */}
      <div className="bg-green-50 border border-green-200 rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ScanLine size={18} className="text-green-600" />
            <span className="font-semibold text-green-900 text-sm">Quick Verify Customer Arrival</span>
          </div>
          {pendingBookings > 0 && (
            <span className="bg-amber-400 text-white text-xs font-bold rounded-full px-2 py-0.5">
              {pendingBookings} pending
            </span>
          )}
        </div>
        <p className="text-xs text-green-700">
          Enter the customer's booking code to check them in instantly.
          {lots.length > 1 && " Uses your first lot — go to Bookings for lot-specific verification."}
        </p>
        <div className="flex gap-2">
          <input
            value={quickCode}
            onChange={(e) => setQuickCode(e.target.value.toUpperCase())}
            onKeyDown={(e) => e.key === "Enter" && handleQuickVerify()}
            placeholder="e.g. BK-A1B2C3D4"
            className="input flex-1 font-mono text-sm uppercase"
          />
          <button
            onClick={handleQuickVerify}
            disabled={!quickCode.trim() || verifying}
            className="btn-primary flex items-center gap-1.5 text-sm px-4 disabled:opacity-50"
          >
            <LogIn size={15} />
            {verifying ? "Checking..." : "Check In"}
          </button>
        </div>
        {pendingBookings > 0 && (
          <button
            onClick={() => navigate("/lot-admin/bookings")}
            className="text-xs text-green-700 font-semibold hover:underline"
          >
            View all {pendingBookings} pending booking{pendingBookings > 1 ? "s" : ""} →
          </button>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: "Total Lots",       value: loading ? "—" : lots.length,            icon: ParkingSquare, color: "text-sp-blue",    bg: "bg-sp-blue/10" },
          { label: "Active Lots",      value: loading ? "—" : activeLots,             icon: TrendingUp,    color: "text-green-600",  bg: "bg-green-50" },
          { label: "Active Bookings",  value: loading ? "—" : activeBookings,         icon: Clock,         color: "text-amber-600",  bg: "bg-amber-50" },
          { label: "Total Revenue",    value: loading ? "—" : formatCurrency(revenue), icon: BarChart2,    color: "text-purple-600", bg: "bg-purple-50" },
        ].map(({ label, value, icon: Icon, color, bg }) => (
          <div key={label} className="stat-card">
            <div className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center flex-shrink-0`}>
              <Icon size={18} className={color} />
            </div>
            <div>
              <div className={`font-display text-xl font-bold ${color}`}>{value}</div>
              <div className="text-xs text-gray-500 mt-0.5">{label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Pending bookings alert */}
      {!loading && pendingBookings > 0 && (
        <button
          onClick={() => navigate("/lot-admin/bookings")}
          className="w-full bg-amber-50 border border-amber-200 rounded-2xl px-4 py-3 flex items-center justify-between text-left hover:bg-amber-100 transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-amber-100 rounded-xl flex items-center justify-center flex-shrink-0">
              <Clock size={16} className="text-amber-600" />
            </div>
            <div>
              <p className="text-sm font-semibold text-amber-900">
                {pendingBookings} booking{pendingBookings > 1 ? "s" : ""} waiting for arrival verification
              </p>
              <p className="text-xs text-amber-600">Tap to view and check them in</p>
            </div>
          </div>
          <ArrowRight size={16} className="text-amber-500 flex-shrink-0" />
        </button>
      )}

      {/* Quick Actions */}
      <div>
        <h2 className="section-title mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          {quickActions.map(({ icon: Icon, label, sub, to, color }) => (
            <button
              key={label}
              onClick={() => navigate(to)}
              className="bg-white border border-gray-100 rounded-2xl p-5 text-left hover:shadow-md hover:border-gray-200 transition-all group active:scale-[0.97]"
            >
              <div className={`w-10 h-10 rounded-xl ${color} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                <Icon size={18} />
              </div>
              <div className="font-semibold text-gray-900 text-sm">{label}</div>
              <div className="text-xs text-gray-400 mt-0.5">{sub}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Recent lots */}
      {!loading && lots.length > 0 ? (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="section-title">My Parking Lots</h2>
            <button onClick={() => navigate("/lot-admin/lots")} className="text-xs text-sp-blue font-semibold hover:underline">
              View all →
            </button>
          </div>
          <div className="space-y-2">
            {lots.slice(0, 4).map((lot) => (
              <div
                key={lot.id}
                onClick={() => navigate(`/lot-admin/lot/${lot.id}`)}
                className="bg-white border border-gray-100 rounded-xl p-4 flex items-center justify-between gap-3 cursor-pointer hover:shadow-sm transition-all"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 ${lot.status === "ACTIVE" ? "bg-green-50" : "bg-gray-50"}`}>
                    <ParkingSquare size={15} className={lot.status === "ACTIVE" ? "text-green-600" : "text-gray-400"} />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-900">{lot.name}</p>
                    <p className="text-xs text-gray-400">{lot.latitude?.toFixed(4)}, {lot.longitude?.toFixed(4)}</p>
                  </div>
                </div>
                <span className={`badge text-xs ${lot.status === "ACTIVE" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"}`}>
                  {lot.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      ) : !loading && !error ? (
        <div className="card text-center py-14">
          <ParkingSquare size={36} className="mx-auto text-gray-300 mb-3" />
          <p className="text-gray-500 text-sm font-medium">No parking lots yet</p>
          <p className="text-gray-400 text-xs mt-1">Add your first lot to start accepting bookings</p>
          <button onClick={() => navigate("/lot-admin/lots")} className="btn-primary mt-4 text-xs">Add Parking Lot</button>
        </div>
      ) : null}
    </div>
  );
};

export default LotAdminDashboard;