import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import axiosInstance from "../../api/axiosInstance";
import { formatCurrency } from "../../utils/formatters";
import { Truck, Car, ClipboardList, TrendingUp, DollarSign, Clock, ArrowRight, Building2, AlertCircle } from "lucide-react";

const FleetDashboard = () => {
  const { user }   = useAuth();
  const navigate   = useNavigate();

  const [company, setCompany]     = useState(null);   // RentalCompany from backend
  const [companyLoading, setCL]   = useState(true);   // loading company status
  const [cars, setCars]           = useState([]);
  const [bookings, setBookings]   = useState([]);
  const [loading, setL]           = useState(false);

  // Step 1: Always fetch company status first
  useEffect(() => {
    axiosInstance.get("/api/rental-company/my")
      .then((r) => setCompany(r.data))
      .catch(() => setCompany(null))
      .finally(() => setCL(false));
  }, []);

  // Step 2: Only fetch fleet data if company is verified
  useEffect(() => {
    if (!company?.platformVerified) return;
    setL(true);
    Promise.all([
      axiosInstance.get(`/api/rental-cars/company/${company.id}`).then((r) => r.data || []).catch(() => []),
      axiosInstance.get(`/api/rental-cars/company/${company.id}/bookings`).then((r) => r.data || []).catch(() => []),
    ]).then(([c, b]) => {
      setCars(c);
      setBookings(b);
    }).finally(() => setL(false));
  }, [company]);

  // ── Loading company status ────────────────────────────────
  if (companyLoading) {
    return (
      <div className="page-container flex items-center justify-center min-h-[60vh]">
        <div className="w-6 h-6 border-2 border-sp-blue border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // ── No company registered yet ─────────────────────────────
  if (!company) {
    return (
      <div className="page-container max-w-md">
        <div className="card text-center py-14 space-y-5">
          <div className="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center mx-auto">
            <Building2 size={24} className="text-sp-blue" />
          </div>
          <div>
            <h2 className="font-display text-xl font-bold text-gray-900">Register Your Company</h2>
            <p className="text-gray-500 text-sm mt-2 max-w-xs mx-auto">
              Before you can list cars, you need to register your rental company and get verified by the admin.
            </p>
          </div>
          <button
            onClick={() => navigate("/fleet-admin/register-company")}
            className="btn-primary flex items-center gap-2 mx-auto"
          >
            <ArrowRight size={15} /> Register Now
          </button>
        </div>
      </div>
    );
  }

  // ── Company registered but not yet verified ───────────────
  if (!company.platformVerified) {
    return (
      <div className="page-container max-w-md">
        <div className="card text-center py-14 space-y-5">
          <div className="w-14 h-14 bg-amber-50 rounded-2xl flex items-center justify-center mx-auto">
            <Clock size={24} className="text-amber-500" />
          </div>
          <div>
            <h2 className="font-display text-xl font-bold text-gray-900">Verification Pending</h2>
            <p className="text-gray-500 text-sm mt-2 max-w-xs mx-auto">
              <span className="font-semibold text-gray-700">{company.companyName}</span> is under review.
              You'll be notified once a super admin approves your account.
            </p>
          </div>
          <div className="inline-flex items-center gap-2 bg-amber-100 text-amber-700 text-xs font-semibold px-3 py-1.5 rounded-full">
            <AlertCircle size={11} /> Awaiting approval · Usually 24–48 hrs
          </div>
          <button
            onClick={() => navigate("/fleet-admin/company-pending")}
            className="btn-secondary text-sm mx-auto"
          >
            View Details
          </button>
        </div>
      </div>
    );
  }

  // ── Company verified — show full dashboard ─────────────────
  const available = cars.filter((c) => c.status === "AVAILABLE").length;
  const rented    = cars.filter((c) => c.status === "RENTED").length;
  const revenue   = bookings.filter((b) => b.status === "COMPLETED")
                            .reduce((s, b) => s + (b.totalAmount || 0), 0);

  const quickActions = [
    { icon: Truck,         label: "My Fleet",        sub: "Manage all cars",    to: "/fleet-admin/fleet",        color: "bg-blue-50 text-blue-600" },
    { icon: Car,           label: "Add Rental Car",  sub: "List a new vehicle", to: "/fleet-admin/fleet?add=1",  color: "bg-green-50 text-green-600" },
    { icon: ClipboardList, label: "Rental Bookings", sub: "All reservations",   to: "/fleet-admin/bookings",     color: "bg-amber-50 text-amber-600" },
  ];

  return (
    <div className="page-container space-y-8">

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900">Fleet Dashboard</h1>
          <p className="text-gray-500 text-sm mt-1">
            Welcome back, <span className="font-medium text-gray-700">{user?.name?.split(" ")[0]}</span> 🚛
          </p>
        </div>
        <button
          onClick={() => navigate("/fleet-admin/fleet?add=1")}
          className="btn-primary flex items-center gap-2 text-sm"
        >
          <Car size={15} /> Add Car <ArrowRight size={14} />
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: "Total Cars",       value: loading ? "—" : cars.length,           icon: Truck,       color: "text-sp-blue",    bg: "bg-sp-blue/10" },
          { label: "Available",        value: loading ? "—" : available,              icon: TrendingUp,  color: "text-green-600",  bg: "bg-green-50" },
          { label: "Currently Rented", value: loading ? "—" : rented,                icon: Clock,       color: "text-amber-600",  bg: "bg-amber-50" },
          { label: "Total Revenue",    value: loading ? "—" : formatCurrency(revenue), icon: DollarSign, color: "text-purple-600", bg: "bg-purple-50" },
        ].map(({ label, value, icon: Icon, color, bg }) => (
          <div key={label} className="stat-card">
            <div className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center flex-shrink-0`}>
              <Icon size={18} className={color} />
            </div>
            <div>
              <div className={`font-display text-xl font-bold ${color}`}>{value}</div>
              <div className="text-xs text-gray-500 mt-0.5">{label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="section-title mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {quickActions.map(({ icon: Icon, label, sub, to, color }) => (
            <button
              key={label}
              onClick={() => navigate(to)}
              className="bg-white border border-gray-100 rounded-2xl p-5 text-left hover:shadow-md hover:border-gray-200 transition-all group active:scale-[0.97]"
            >
              <div className={`w-10 h-10 rounded-xl ${color} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                <Icon size={18} />
              </div>
              <div className="font-semibold text-gray-900 text-sm">{label}</div>
              <div className="text-xs text-gray-400 mt-0.5">{sub}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Recent bookings */}
      {!loading && bookings.length > 0 ? (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="section-title">Recent Bookings</h2>
            <button onClick={() => navigate("/fleet-admin/bookings")} className="text-xs text-sp-blue font-semibold hover:underline">
              View all →
            </button>
          </div>
          <div className="space-y-2">
            {bookings.slice(0, 4).map((b) => (
              <div key={b.id} className="bg-white border border-gray-100 rounded-xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 bg-purple-50 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Truck size={15} className="text-purple-600" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-900">{b.carMake} {b.carModel}</p>
                    <p className="text-xs text-gray-400">{b.customerName ?? `Customer #${b.customerId}`}</p>
                  </div>
                </div>
                <div className="text-right">
                  {b.totalAmount != null && <p className="text-sm font-bold text-sp-blue">{formatCurrency(b.totalAmount)}</p>}
                  <span className={`badge text-xs ${
                    b.status === "ACTIVE"    ? "bg-green-100 text-green-700"   :
                    b.status === "COMPLETED" ? "bg-gray-100 text-gray-600"     :
                    b.status === "PENDING"   ? "bg-yellow-100 text-yellow-700" :
                    "bg-gray-100 text-gray-600"
                  }`}>{b.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : !loading ? (
        <div className="card text-center py-14">
          <Truck size={36} className="mx-auto text-gray-300 mb-3" />
          <p className="text-gray-500 text-sm font-medium">No cars in your fleet yet</p>
          <p className="text-gray-400 text-xs mt-1">Add your first rental car to start accepting bookings</p>
          <button onClick={() => navigate("/fleet-admin/fleet?add=1")} className="btn-primary mt-4 text-xs">
            Add a Car
          </button>
        </div>
      ) : null}
    </div>
  );
};

export default FleetDashboard;