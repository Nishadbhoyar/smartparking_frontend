import { useEffect, useState, useCallback } from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import axiosInstance from "../../api/axiosInstance";
import { formatCurrency } from "../../utils/formatters";
import toast from "react-hot-toast";
import {
  CheckCircle,
  XCircle,
  Loader,
  CreditCard,
  ChevronLeft,
  RefreshCw,
  Phone,
  Clock
} from "lucide-react";

// ── Cashfree SDK ──────────────────────────────────────────────────────────────
const CASHFREE_MODE = import.meta.env.VITE_CASHFREE_MODE || "sandbox";

const loadCashfreeSDK = () =>
  new Promise((resolve, reject) => {
    if (window.Cashfree) return resolve(window.Cashfree);
    const script = document.createElement("script");
    script.src = "https://sdk.cashfree.com/js/v3/cashfree.js";
    script.async = true;
    script.onload = () =>
      window.Cashfree ? resolve(window.Cashfree) : reject(new Error("Cashfree SDK failed to load"));
    script.onerror = () => reject(new Error("Cashfree SDK script error"));
    document.body.appendChild(script);
  });

// ── Polling config ────────────────────────────────────────────────────────────
const POLL_INTERVAL_MS = 3000;
const MAX_POLLS = 20; // 60 seconds total polling time

// ── Service labels ────────────────────────────────────────────────────────────
const SERVICE_LABELS = {
  PARKING_BOOKING: "Parking Slot",
  CAR_RENTAL:      "Car Rental",
  VALET:           "Valet Service",
};

const SUCCESS_MESSAGES = {
  PARKING_BOOKING: "Your parking slot is confirmed.",
  CAR_RENTAL:      "Your car rental is confirmed.",
  VALET:           "Valet payment complete.",
};

// ── Component ─────────────────────────────────────────────────────────────────
const PaymentPage = () => {
  const { serviceType, referenceId } = useParams();
  const { state: routeState }        = useLocation();
  const navigate                     = useNavigate();
  const { user }                     = useAuth();

  const [serviceData,   setServiceData]   = useState(routeState?.serviceData ?? null);
  const [loadingData,   setLoadingData]   = useState(!routeState?.serviceData);

  const [phone,         setPhone]         = useState("");
  const [phoneError,    setPhoneError]    = useState("");
  
  // STAGES: enter_phone -> loading -> paying -> polling -> success | failed | pending (timeout)
  const [stage,         setStage]         = useState("enter_phone");
  const [paymentStatus, setPaymentStatus] = useState(null);
  const [pollCount,     setPollCount]     = useState(0);
  const [sdkReady,      setSdkReady]      = useState(false);

  // ── Load service details if not passed via router state ───────────────────
  useEffect(() => {
    if (serviceData) return; 
    if (!serviceType || !referenceId || !user) return;

    const load = async () => {
      setLoadingData(true);
      try {
        let data;
        switch (serviceType) {
          case "PARKING_BOOKING": {
            const res = await axiosInstance.get(`/api/bookings/${referenceId}`);
            data = {
              referenceCode: res.data.bookingCode,
              amount:        res.data.totalAmount,
              label:         SERVICE_LABELS.PARKING_BOOKING,
              lines: [
                { key: "Lot",  value: res.data.parkingLotName },
                { key: "Slot", value: res.data.slotNumber },
              ],
            };
            break;
          }
          case "CAR_RENTAL": {
            const res = await axiosInstance.get(`/api/rental-cars/customer/${user.id}/bookings`);
            const booking = (res.data || []).find((b) => String(b.id) === String(referenceId));
            if (!booking) throw new Error("Rental booking not found");
            data = {
              referenceCode: booking.bookingCode,
              amount:        booking.totalAmount,
              label:         SERVICE_LABELS.CAR_RENTAL,
              lines: [
                { key: "Car",  value: `${booking.carMake} ${booking.carModel}` },
                { key: "From", value: new Date(booking.startTime).toLocaleDateString() },
                { key: "To",   value: new Date(booking.endTime).toLocaleDateString() },
              ],
            };
            break;
          }
          case "VALET": {
            const [reqRes, fareRes] = await Promise.all([
              axiosInstance.get(`/api/valet/request/${referenceId}`),
              axiosInstance.get(`/api/valet/fare/${referenceId}`),
            ]);
            data = {
              referenceCode: `VLT-${referenceId}`,
              amount:        fareRes.data.totalFare,
              label:         SERVICE_LABELS.VALET,
              lines: [
                { key: "Plate",    value: reqRes.data.carPlateNo },
                { key: "Base",     value: formatCurrency(fareRes.data.baseFare) },
                { key: "Distance", value: formatCurrency(fareRes.data.distanceFare) },
                fareRes.data.parkingFare > 0 ? { key: "Parking", value: formatCurrency(fareRes.data.parkingFare) } : null,
                fareRes.data.surgeFare > 0 ? { key: "Surge", value: formatCurrency(fareRes.data.surgeFare) } : null,
              ].filter(Boolean),
            };
            break;
          }
          default:
            throw new Error("Unknown service type: " + serviceType);
        }
        setServiceData(data);
      } catch (err) {
        toast.error("Could not load payment details. Please go back and try again.");
      } finally {
        setLoadingData(false);
      }
    };
    load();
  }, [serviceType, referenceId, user, serviceData]);

  // ── Preload Cashfree SDK ──────────────────────────────────────────────────
  useEffect(() => {
    loadCashfreeSDK()
      .then(() => setSdkReady(true))
      .catch(() => toast.error("Payment SDK failed to load. Refresh and try again."));
  }, []);

  // ── Phone validation ──────────────────────────────────────────────────────
  const validatePhone = (value) => {
    if (!value || value.trim().length !== 10 || !/^\d{10}$/.test(value.trim())) {
      setPhoneError("Enter a valid 10-digit mobile number");
      return false;
    }
    setPhoneError("");
    return true;
  };

  // ── Initiate payment ──────────────────────────────────────────────────────
  const handlePay = async () => {
    if (!validatePhone(phone)) return;
    if (!sdkReady) return toast.error("Payment SDK still loading. Please wait.");

    setStage("loading");
    try {
      const { data } = await axiosInstance.post("/api/payments/initiate", {
        serviceType,
        referenceId: Number(referenceId),
        customerPhone: phone.trim(),
      });

      const { paymentSessionId } = data;
      if (!paymentSessionId) throw new Error("No session ID returned");

      setStage("paying");
      const cashfree = window.Cashfree({ mode: CASHFREE_MODE });
      
      // 🚨 FIX: Capture the result of the modal explicitly
      const result = await cashfree.checkout({ paymentSessionId, redirectTarget: "_modal" });

      if (result.error) {
        // Cashfree throws an error if the user clicks the "X" on the modal
        console.warn("Payment Modal Closed/Error:", result.error.message);
        setStage("failed");
        setPaymentStatus({ status: "USER_DROPPED", failureReason: "Payment window was closed or cancelled." });
      } else {
        // Payment completed (either successfully or bank declined), start backend polling
        setStage("polling");
        startPolling();
      }
    } catch (err) {
      console.error("Payment error:", err);
      setStage("enter_phone");
      toast.error(err.response?.data?.message || "Payment could not be started. Try again.");
    }
  };

  // ── Poll backend for payment result ────────────────────────────────────────
  const startPolling = useCallback(() => {
    let count = 0;
    const interval = setInterval(async () => {
      count++;
      setPollCount(count);
      try {
        const { data } = await axiosInstance.get("/api/payments/status", {
          params: { serviceType, referenceId },
        });
        
        setPaymentStatus(data);

        // 1. Payment Went Through
        if (data.status === "SUCCESS") {
          clearInterval(interval);
          setStage("success");
          toast.success("Payment successful!");
        } 
        // 2. Payment Failed or User Cancelled/Closed Popup
        else if (data.status === "FAILED" || data.status === "USER_DROPPED") {
          clearInterval(interval);
          setStage("failed");
        } 
        // 3. Bank is taking too long (Pending State)
        else if (count >= MAX_POLLS) {
          clearInterval(interval);
          setStage("pending");
        }
      } catch {
        // network blip — keep polling silently
      }
    }, POLL_INTERVAL_MS);
  }, [serviceType, referenceId]);

  // ── Retry ────────────────────────────────────────────────────────────────
  const handleRetry = () => {
    setStage("enter_phone");
    setPaymentStatus(null);
    setPollCount(0);
  };

  const handleDone = () => {
    if (serviceType === "VALET") navigate("/customer/dashboard");
    else navigate("/customer/bookings");
  };

  // ── Loading service data ──────────────────────────────────────────────────
  if (loadingData || !serviceData) {
    return (
      <div className="page-container max-w-md flex items-center justify-center py-24">
        <Loader size={28} className="text-sp-blue animate-spin" />
      </div>
    );
  }

  // ── 1. SUCCESS STATE ──────────────────────────────────────────────────────
  if (stage === "success") {
    return (
      <div className="page-container max-w-md space-y-6">
        <div className="card text-center py-10 space-y-4">
          <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle size={32} className="text-green-500" />
          </div>
          <div>
            <h2 className="font-display text-2xl font-bold text-gray-900">Payment Successful</h2>
            <p className="text-gray-500 text-sm mt-1">
              {SUCCESS_MESSAGES[serviceType] || "Your payment is confirmed."}
            </p>
          </div>
          <div className="bg-gray-50 rounded-2xl p-4 text-left space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-500">Reference</span>
              <span className="font-mono font-bold">{serviceData.referenceCode}</span>
            </div>
            {serviceData.lines.map(({ key, value }) => (
              <div key={key} className="flex justify-between">
                <span className="text-gray-500">{key}</span>
                <span className="font-semibold">{value}</span>
              </div>
            ))}
            {paymentStatus?.paymentMethod && (
              <div className="flex justify-between">
                <span className="text-gray-500">Paid via</span>
                <span className="font-semibold capitalize">{paymentStatus.paymentMethod}</span>
              </div>
            )}
            <div className="flex justify-between pt-2 border-t border-gray-200 font-bold text-base">
              <span>Amount Paid</span>
              <span className="text-sp-blue">{formatCurrency(serviceData.amount)}</span>
            </div>
          </div>
          <div className="flex gap-3">
            {serviceType !== "VALET" && (
              <button onClick={() => navigate("/customer/bookings")} className="btn-secondary flex-1 text-sm">
                My Bookings
              </button>
            )}
            <button onClick={handleDone} className="btn-primary flex-1 text-sm">
              Done
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── 2. FAILED OR CANCELLED STATE ──────────────────────────────────────────
  if (stage === "failed") {
    return (
      <div className="page-container max-w-md space-y-6">
        <div className="card text-center py-10 space-y-4">
          <div className="w-16 h-16 bg-red-50 rounded-full flex items-center justify-center mx-auto">
            <XCircle size={32} className="text-red-500" />
          </div>
          <div>
            <h2 className="font-display text-2xl font-bold text-gray-900">Payment Failed</h2>
            <p className="text-gray-500 text-sm mt-1 px-4">
              {paymentStatus?.status === "USER_DROPPED" 
                ? "The payment window was closed before completing the transaction." 
                : (paymentStatus?.failureReason || "Something went wrong with your bank or card.")}
            </p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={handleRetry}
              className="btn-primary flex-1 text-sm flex items-center justify-center gap-2"
            >
              <RefreshCw size={14} /> Try Again
            </button>
            <button onClick={handleDone} className="btn-secondary flex-1 text-sm">
              {serviceType === "VALET" ? "Dashboard" : "My Bookings"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── 3. PENDING STATE (Bank delay / Timeout) ───────────────────────────────
  if (stage === "pending") {
    return (
      <div className="page-container max-w-md space-y-6">
        <div className="card text-center py-12 space-y-5">
          <div className="w-16 h-16 bg-amber-50 rounded-full flex items-center justify-center mx-auto">
            <Clock size={32} className="text-amber-500" />
          </div>
          <div>
            <h2 className="font-display text-xl font-bold text-gray-900">Payment is Pending</h2>
            <p className="text-gray-500 text-sm mt-2 px-2">
              We are waiting for confirmation from your bank. This can sometimes take a few minutes. 
            </p>
          </div>
          
          <div className="bg-gray-50 p-4 rounded-xl text-sm text-left text-gray-600 space-y-2">
             <p>• If money was deducted, it will be automatically updated or refunded.</p>
             <p>• You can safely leave this page and check your status in the Dashboard later.</p>
          </div>

          <div className="flex gap-3 mt-4">
             <button onClick={() => { setStage("polling"); startPolling(); }} className="btn-secondary flex-1 text-sm flex items-center justify-center gap-2">
               <RefreshCw size={14} /> Check Status Again
             </button>
             <button onClick={handleDone} className="btn-primary flex-1 text-sm">
               Go to Dashboard
             </button>
          </div>
        </div>
      </div>
    );
  }

  // ── 4. POLLING STATE (Actively Waiting) ───────────────────────────────────
  if (stage === "polling") {
    return (
      <div className="page-container max-w-md space-y-6">
        <div className="card text-center py-12 space-y-5">
          <Loader size={36} className="mx-auto text-sp-blue animate-spin" />
          <div>
            <h2 className="font-display text-xl font-bold text-gray-900">Confirming Payment</h2>
            <p className="text-gray-500 text-sm mt-1">
              Checking securely with Cashfree… ({pollCount * 3}s elapsed)
            </p>
          </div>
          <p className="text-xs text-gray-400">Please do not close or refresh this page.</p>
        </div>
      </div>
    );
  }

  // ── 5. ENTER PHONE + SUMMARY (Default Checkout View) ──────────────────────
  return (
    <div className="page-container max-w-md space-y-6">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-900 transition-colors"
      >
        <ChevronLeft size={16} /> Back
      </button>

      <div>
        <h1 className="font-display text-2xl font-bold text-gray-900">Complete Payment</h1>
        <p className="text-gray-500 text-sm mt-1">
          {serviceData.label} · Secure payment via Cashfree
        </p>
      </div>

      {/* Order Summary */}
      <div className="card space-y-3">
        <h2 className="section-title">Order Summary</h2>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between text-gray-600">
            <span>Reference</span>
            <span className="font-mono font-semibold">{serviceData.referenceCode}</span>
          </div>
          {serviceData.lines.map(({ key, value }) => (
            <div key={key} className="flex justify-between text-gray-600">
              <span>{key}</span>
              <span className="font-semibold text-gray-900">{value}</span>
            </div>
          ))}
          <div className="flex justify-between font-bold text-gray-900 pt-2 border-t border-gray-100 text-base">
            <span>Total</span>
            <span className="text-sp-blue">{formatCurrency(serviceData.amount)}</span>
          </div>
        </div>
      </div>

      {/* Phone Number */}
      <div className="card space-y-4">
        <h2 className="section-title">Mobile Number</h2>
        <p className="text-xs text-gray-500 -mt-2">Required by Cashfree for payment processing.</p>
        <div className="space-y-1.5">
          <div className="relative">
            <Phone size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="tel"
              value={phone}
              onChange={(e) => {
                const v = e.target.value.replace(/\D/g, "").slice(0, 10);
                setPhone(v);
                if (phoneError) validatePhone(v);
              }}
              placeholder="10-digit mobile number"
              className={`input pl-10 tracking-wider ${phoneError ? "border-red-300 focus:ring-red-200" : ""}`}
              maxLength={10}
              onKeyDown={(e) => e.key === "Enter" && handlePay()}
            />
          </div>
          {phoneError && <p className="text-xs text-red-500">{phoneError}</p>}
        </div>

        <button
          onClick={handlePay}
          disabled={stage === "loading" || !sdkReady}
          className="w-full btn-primary py-3.5 text-base flex items-center justify-center gap-2 disabled:opacity-60"
        >
          {stage === "loading" ? (
            <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
          ) : (
            <>
              <CreditCard size={17} />
              Pay {formatCurrency(serviceData.amount)}
            </>
          )}
        </button>

        {!sdkReady && (
          <p className="text-xs text-center text-gray-400">Loading payment SDK…</p>
        )}
      </div>

      {/* Security note */}
      <div className="bg-blue-50 border border-blue-100 rounded-2xl p-4 text-xs text-blue-800 space-y-1">
        <p className="font-semibold">🔒 Secure Payment</p>
        <p>
          Your payment is processed by Cashfree, a PCI-DSS compliant payment gateway.
          We never store your card details.
        </p>
      </div>
    </div>
  );
};

export default PaymentPage;