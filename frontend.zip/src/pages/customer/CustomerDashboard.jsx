import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import axiosInstance from "../../api/axiosInstance";
import { formatDate, formatCurrency, statusColor } from "../../utils/formatters";
import {
  MapPin, CalendarCheck, Car, ArrowRight, Clock, TrendingUp,
  ParkingSquare, Zap, KeyRound, Copy, Loader2, Camera,
} from "lucide-react";
import toast from "react-hot-toast";
import ValetCarImages from "../valet/ValetCarImages"

// ── Active Valet Card ─────────────────────────────────────────────────────────

const VALET_STATUS_META = {
  REQUESTED:        { label: "Finding Valet",    color: "bg-amber-100 text-amber-700",   desc: "Looking for an available valet near you." },
  ACCEPTED:         { label: "Valet Assigned",   color: "bg-blue-100 text-blue-700",     desc: "Your valet is on the way to your location." },
  PICKED_UP:        { label: "Keys Collected",   color: "bg-indigo-100 text-indigo-700", desc: "Valet has your keys and is driving to the lot." },
  PARKED:           { label: "Car Parked",        color: "bg-green-100 text-green-700",   desc: "Your car is safely parked. Request it back when ready." },
  RETURN_REQUESTED: { label: "Car Returning",    color: "bg-purple-100 text-purple-700", desc: "Valet is bringing your car back to you." },
  RETURN_REQ:       { label: "Car Returning",    color: "bg-purple-100 text-purple-700", desc: "Valet is bringing your car back to you." },
};

const normalise = (s) => (s === "RETURN_REQ" ? "RETURN_REQUESTED" : s);

const ActiveValetCard = ({ job, onReturnRequested }) => {
  const navigate           = useNavigate();
  const [requesting, setR] = useState(false);
  const status             = normalise(job.status);
  const meta               = VALET_STATUS_META[status] ?? { label: status, color: "bg-gray-100 text-gray-700", desc: "" };

  const hasImages = job.carImageIds && job.carImageIds.length > 0;

  const copyOtp = (otp) => {
    navigator.clipboard?.writeText(otp).catch(() => {});
    toast.success("OTP copied!");
  };

  const handleReturn = async () => {
    setR(true);
    try {
      await axiosInstance.post(`/api/valet/${job.id}/request-return`);
      toast.success("Return requested! Valet is on the way.");
      onReturnRequested();
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to request return.");
    } finally {
      setR(false);
    }
  };

  return (
    <div className="bg-gradient-to-br from-sp-dark to-gray-800 rounded-2xl p-5 space-y-4 text-white">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-white/10 rounded-xl flex items-center justify-center">
            <Car size={16} className="text-sp-blue" />
          </div>
          <div>
            <p className="font-semibold text-sm">Valet Service</p>
            <p className="text-xs text-gray-400">Request #{job.id} · {job.carPlateNo}</p>
          </div>
        </div>
        <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${meta.color}`}>
          {meta.label}
        </span>
      </div>

      <p className="text-xs text-gray-300">{meta.desc}</p>

      {(status === "REQUESTED" || status === "ACCEPTED") && job.pickupOtp && (
        <div className="bg-white/10 rounded-xl px-4 py-3 flex items-center justify-between">
          <div>
            <p className="text-xs text-gray-400 flex items-center gap-1 mb-1">
              <KeyRound size={11} /> Pickup OTP — show to valet
            </p>
            <span className="font-mono text-xl font-bold tracking-[0.25em] text-white">
              {job.pickupOtp}
            </span>
          </div>
          <button onClick={() => copyOtp(job.pickupOtp)} className="text-gray-400 hover:text-white transition-colors">
            <Copy size={15} />
          </button>
        </div>
      )}

      {(status === "PARKED" || status === "RETURN_REQUESTED") && job.parkingLotName && (
        <div className="bg-white/10 rounded-xl px-4 py-3">
          <p className="text-xs text-gray-400 flex items-center gap-1 mb-0.5">
            <MapPin size={11} /> Parked at
          </p>
          <p className="text-sm font-semibold">
            {job.parkingLotName}
            {job.slotNumber && <span className="text-gray-400 font-normal"> · Slot {job.slotNumber}</span>}
          </p>
        </div>
      )}

      {(status === "PARKED" || status === "RETURN_REQUESTED") && hasImages && (
        <div className="space-y-2">
          <p className="text-xs text-gray-400 flex items-center gap-1">
            <Camera size={11} /> Car photos taken by valet
          </p>
          <ValetCarImages imageIds={job.carImageIds} />
        </div>
      )}

      {status === "RETURN_REQUESTED" && job.dropoffOtp && (
        <div className="bg-white/10 rounded-xl px-4 py-3 flex items-center justify-between">
          <div>
            <p className="text-xs text-gray-400 flex items-center gap-1 mb-1">
              <KeyRound size={11} /> Dropoff OTP — give to valet on arrival
            </p>
            <span className="font-mono text-xl font-bold tracking-[0.25em] text-green-400">
              {job.dropoffOtp}
            </span>
          </div>
          <button onClick={() => copyOtp(job.dropoffOtp)} className="text-gray-400 hover:text-white transition-colors">
            <Copy size={15} />
          </button>
        </div>
      )}

      <div className="flex gap-2 pt-1">
        <button onClick={() => navigate(`/customer/valet/track/${job.id}`)}
          className="flex-1 bg-white/10 hover:bg-white/20 text-white text-xs font-semibold py-2.5 rounded-xl transition-colors flex items-center justify-center gap-1.5">
          <MapPin size={13} /> Track Live
        </button>
        {status === "PARKED" && (
          <button onClick={handleReturn} disabled={requesting}
            className="flex-1 bg-sp-blue hover:bg-sp-blue/90 text-white text-xs font-semibold py-2.5 rounded-xl transition-colors flex items-center justify-center gap-1.5 disabled:opacity-60">
            {requesting ? <Loader2 size={13} className="animate-spin" /> : <><Car size={13} /> Request Car Back</>}
          </button>
        )}
      </div>
    </div>
  );
};

// ── Main Dashboard ────────────────────────────────────────────────────────────

const CustomerDashboard = () => {
  const { user }   = useAuth();
  const navigate   = useNavigate();

  const [bookings, setBookings] = useState([]);
  const [rentals,  setRentals]  = useState([]);
  const [valets,   setValets]   = useState([]); // 🚨 NEW: Store valet history for stats
  const [valetJob, setValetJob] = useState(null);
  const [loading,  setLoading]  = useState(true);

  const loadData = () => {
    if (!user?.id) return;
    Promise.all([
      axiosInstance.get(`/api/bookings/customer/${user.id}`).then((r) => r.data || []).catch(() => []),
      axiosInstance.get(`/api/rental-cars/customer/${user.id}/bookings`).then((r) => r.data || []).catch(() => []),
      axiosInstance.get(`/api/valet/customer/${user.id}/active`).then((r) => r.status === 204 ? null : r.data).catch(() => null),
      // 🚨 NEW: Fetch full valet history for accurate statistics
      axiosInstance.get(`/api/valet/customer/${user.id}`).then((r) => Array.isArray(r.data) ? r.data : (r.data ? [r.data] : [])).catch(() => []),
    ]).then(([b, r, vActive, vAll]) => {
      setBookings(b);
      setRentals(r);
      setValetJob(vActive);
      setValets(vAll);
    }).finally(() => setLoading(false));
  };

  useEffect(() => { loadData(); }, [user]);

  const handleReturnRequested = () => {
    axiosInstance.get(`/api/valet/customer/${user.id}/active`)
      .then((r) => setValetJob(r.status === 204 ? null : r.data))
      .catch(() => {});
  };

  // 🚨 NEW: Aggregate calculations across ALL types of bookings
  const activeParking = bookings.filter((b) => b.status === "ACTIVE" || b.status === "PENDING");
  const activeRentals = rentals.filter((r) => r.status === "ACTIVE" || r.status === "CONFIRMED");
  const activeValets  = valets.filter((v) => ["REQUESTED", "ACCEPTED", "PICKED_UP", "PARKED", "RETURN_REQUESTED"].includes(v.status));

  const totalActiveBookings = activeParking.length + activeRentals.length + activeValets.length;
  const totalBookingsCount  = bookings.length + rentals.length + valets.length;
  const totalCompletedCount = bookings.filter(b => b.status === "COMPLETED").length +
                              rentals.filter(r => r.status === "COMPLETED").length +
                              valets.filter(v => v.status === "COMPLETED").length;

  // Sums up spend across Parking Slots & Rental Cars
  const totalSpent = 
    bookings.filter(b => b.status === "COMPLETED").reduce((s, b) => s + (b.totalAmount || 0), 0) +
    rentals.filter(r => r.status === "COMPLETED").reduce((s, r) => s + (r.totalAmount || 0), 0);

  const quickActions = [
    { icon: MapPin,        label: "Find Parking",  sub: "Spots near you",  to: "/customer/find-parking",  light: "bg-blue-50 text-blue-600" },
    { icon: Car,           label: "Request Valet", sub: "We park for you", to: "/customer/valet/request", light: "bg-emerald-50 text-emerald-600" },
    { icon: CalendarCheck, label: "My Bookings",   sub: "View history",    to: "/customer/bookings",      light: "bg-amber-50 text-amber-600" },
    { icon: Zap,           label: "Rent a Car",    sub: "Cars near you",   to: "/customer/rentals",       light: "bg-purple-50 text-purple-600" },
  ];

  return (
    <div className="page-container space-y-8">
      {/* Greeting */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-gray-900">
            Good {new Date().getHours() < 12 ? "morning" : new Date().getHours() < 17 ? "afternoon" : "evening"},{" "}
            <span className="text-sp-blue">{user?.name?.split(" ")[0]}</span> 👋
          </h1>
          <p className="text-gray-500 text-sm mt-1">Here's your parking activity at a glance.</p>
        </div>
        <button onClick={() => navigate("/customer/find-parking")} className="btn-primary flex items-center gap-2 self-start sm:self-auto">
          <MapPin size={15} /> Find Parking <ArrowRight size={14} />
        </button>
      </div>

      {/* Active Valet Card */}
      {!loading && valetJob && (
        <div>
          <h2 className="section-title mb-3">Active Valet Job</h2>
          <ActiveValetCard job={valetJob} onReturnRequested={handleReturnRequested} />
        </div>
      )}

      {/* 🚨 FIX: Stats now use the aggregated counts! */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Active Bookings", value: loading ? "—" : totalActiveBookings,      icon: ParkingSquare, color: "text-sp-blue",     bg: "bg-sp-blue/10" },
          { label: "Total Bookings",  value: loading ? "—" : totalBookingsCount,       icon: CalendarCheck, color: "text-emerald-600", bg: "bg-emerald-50" },
          { label: "Completed",       value: loading ? "—" : totalCompletedCount,      icon: TrendingUp,    color: "text-amber-600",   bg: "bg-amber-50" },
          { label: "Total Spent",     value: loading ? "—" : formatCurrency(totalSpent), icon: Clock,         color: "text-purple-600",  bg: "bg-purple-50" },
        ].map(({ label, value, icon: Icon, color, bg }) => (
          <div key={label} className="stat-card">
            <div className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center flex-shrink-0`}>
              <Icon size={18} className={color} />
            </div>
            <div>
              <div className={`font-display text-xl font-bold ${color}`}>{value}</div>
              <div className="text-xs text-gray-500 mt-0.5">{label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="section-title mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {quickActions.map(({ icon: Icon, label, sub, to, light }) => (
            <button key={to} onClick={() => navigate(to)}
              className="bg-white border border-gray-100 rounded-2xl p-5 text-left hover:shadow-md hover:border-gray-200 transition-all group active:scale-[0.97]">
              <div className={`w-10 h-10 rounded-xl ${light} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                <Icon size={18} />
              </div>
              <div className="font-semibold text-gray-900 text-sm">{label}</div>
              <div className="text-xs text-gray-400 mt-0.5">{sub}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Active Rental Cars */}
      {rentals.filter((r) => r.status === "ACTIVE" || r.status === "CONFIRMED").length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="section-title">Active Car Rentals</h2>
            <span className="text-xs bg-purple-100 text-purple-700 font-medium px-2 py-0.5 rounded-full">
              {rentals.filter((r) => r.status === "ACTIVE" || r.status === "CONFIRMED").length} active
            </span>
          </div>
          <div className="space-y-3">
            {rentals
              .filter((r) => r.status === "ACTIVE" || r.status === "CONFIRMED")
              .map((r) => (
                <div key={r.id} className="bg-white border border-gray-100 rounded-2xl p-4 flex items-center justify-between gap-4 hover:shadow-sm transition-shadow">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-purple-50 rounded-xl flex items-center justify-center">
                      <Car size={18} className="text-purple-600" />
                    </div>
                    <div>
                      <div className="font-semibold text-sm text-gray-900">{r.carMake} {r.carModel}</div>
                      <div className="text-xs text-gray-500 mt-0.5">
                        {r.licensePlate} · Until {formatDate(r.endTime)}
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-1.5">
                    <span className={`badge ${r.status === "ACTIVE" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`}>
                      {r.status}
                    </span>
                    {r.status === "CONFIRMED" && r.pickupOtp && (
                      <span className="text-xs font-mono bg-gray-100 text-gray-700 px-2 py-1 rounded-lg border border-gray-200">
                        Pickup OTP: <strong className="text-gray-900">{r.pickupOtp}</strong>
                      </span>
                    )}
                    {r.status === "ACTIVE" && r.returnOtp && (
                      <span className="text-xs font-mono bg-green-50 text-green-700 px-2 py-1 rounded-lg border border-green-200">
                        Return OTP: <strong className="text-green-900">{r.returnOtp}</strong>
                      </span>
                    )}
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Active parking bookings */}
      {activeParking.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="section-title">Active Bookings</h2>
            <span className="text-xs bg-green-100 text-green-700 font-medium px-2 py-0.5 rounded-full">
              {activeParking.length} active
            </span>
          </div>
          <div className="space-y-3">
            {activeParking.map((b) => (
              <div key={b.id} className="bg-white border border-gray-100 rounded-2xl p-4 flex items-center justify-between gap-4 hover:shadow-sm transition-shadow">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-50 rounded-xl flex items-center justify-center">
                    <ParkingSquare size={18} className="text-green-600" />
                  </div>
                  <div>
                    <div className="font-semibold text-sm text-gray-900">{b.parkingLotName}</div>
                    <div className="text-xs text-gray-500 mt-0.5">
                      Slot {b.slotNumber} · {formatDate(b.entryTime)}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`badge ${statusColor(b.status)}`}>{b.status}</span>
                  {b.status === "ACTIVE" && (
                    <button onClick={() => navigate(`/customer/checkout/${b.id}`)}
                      className="text-xs btn-primary py-1.5 px-3">
                      Checkout
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent bookings */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="section-title">Recent Parking Bookings</h2>
          <button onClick={() => navigate("/customer/bookings")}
            className="text-xs text-sp-blue font-semibold hover:underline flex items-center gap-1">
            View all <ArrowRight size={12} />
          </button>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white rounded-2xl border border-gray-100 p-4 animate-pulse">
                <div className="flex gap-3">
                  <div className="w-10 h-10 bg-gray-100 rounded-xl" />
                  <div className="flex-1 space-y-2">
                    <div className="h-3 bg-gray-100 rounded w-1/2" />
                    <div className="h-3 bg-gray-100 rounded w-1/3" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : bookings.length === 0 ? (
          <div className="bg-white border border-gray-100 rounded-2xl p-12 text-center">
            <ParkingSquare size={32} className="mx-auto text-gray-300 mb-3" />
            <p className="text-gray-500 text-sm font-medium">No bookings yet</p>
            <p className="text-gray-400 text-xs mt-1">Find a nearby lot and make your first booking</p>
            <button onClick={() => navigate("/customer/find-parking")} className="btn-primary mt-4 text-xs">
              Find Parking
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {bookings.slice(0, 5).map((b) => (
              <div key={b.id} className="bg-white border border-gray-100 rounded-xl p-4 flex items-center justify-between gap-4 hover:shadow-sm transition-all">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gray-50 rounded-xl flex items-center justify-center">
                    <ParkingSquare size={15} className="text-gray-500" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-gray-900">{b.parkingLotName}</div>
                    <div className="text-xs text-gray-400">{formatDate(b.entryTime)}</div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {b.totalAmount > 0 && (
                    <span className="text-sm font-semibold text-gray-700">{formatCurrency(b.totalAmount)}</span>
                  )}
                  <span className={`badge ${statusColor(b.status)}`}>{b.status}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CustomerDashboard;